# cs324-A1
This is the assignment repo for the course CS324 based on distributed computing systems.
What is this?

A small distributed system made of several Java programs that talk to each other using Java RMI.
Bootstrap — remembers which workers are online
Workers — do the real work and elect one leader
Client (GUI) — you type a job (or load a CSV) and get an answer
The leader splits the job across the workers. After 5 jobs, they elect a new leader.

What should happen?
Start Bootstrap → it waits for workers.
Start a few Workers → they join and pick neighbours.
Start the Client → submit jobs like:

PRIMESUM from 1 to 50 → answer 328
PRIMECOUNT from 1 to 100 → answer 25
MAX from 1 to 500 → answer 500

After 5 jobs, workers elect a new coordinator (watch the worker terminals).


HOW TO RUN
First Import the project from the zip or open it
Run BoostStrapNode FIle first
Then run the WorkerNode File a couple of times to add workers
Then run the ClientGUI file 
