package cs324.assignment1.bootstrap;

import cs324.assignment1.common.BootstrapService;
import cs324.assignment1.common.WorkerInfo;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class BootstrapServiceImpl extends UnicastRemoteObject implements BootstrapService {

    private final Map<Integer, WorkerInfo> activeWorkers = new ConcurrentHashMap<>();
    private final AtomicInteger idCounter = new AtomicInteger(1);

    protected BootstrapServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public synchronized int registerWorker(String workerHost, int workerPort) throws RemoteException {
        int newId = idCounter.getAndIncrement();
        WorkerInfo info = new WorkerInfo(newId, workerHost, workerPort);
        activeWorkers.put(newId, info);
        System.out.println("[Bootstrap] Registered worker " + newId + " at " + workerHost + ":" + workerPort);
        return newId;
    }

    @Override
    public void deregisterWorker(int workerId) throws RemoteException {
        activeWorkers.remove(workerId);
        System.out.println("[Bootstrap] Deregistered worker " + workerId);
    }

    @Override
    public List<WorkerInfo> getActiveWorkers() throws RemoteException {
        return List.copyOf(activeWorkers.values());
    }
}