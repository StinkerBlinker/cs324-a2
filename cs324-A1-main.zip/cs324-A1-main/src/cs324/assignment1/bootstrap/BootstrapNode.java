package cs324.assignment1.bootstrap;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class BootstrapNode {

    public static final String SERVICE_NAME = "BootstrapService";
    public static final int RMI_PORT = 1099; // default RMI registry port

    public static void main(String[] args) {
        try {
            // Starts an RMI registry programmatically (no need to run
            // the standalone `rmiregistry` command manually).
            Registry registry = LocateRegistry.createRegistry(RMI_PORT);

            BootstrapServiceImpl service = new BootstrapServiceImpl();
            registry.rebind(SERVICE_NAME, service);

            System.out.println("[Bootstrap] Node started on port " + RMI_PORT);
            System.out.println("[Bootstrap] Waiting for workers to register...");
        } catch (Exception e) {
            System.err.println("[Bootstrap] Failed to start: " + e.getMessage());
            e.printStackTrace();
        }
    }
}