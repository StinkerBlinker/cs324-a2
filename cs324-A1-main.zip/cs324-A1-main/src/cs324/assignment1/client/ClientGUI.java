package cs324.assignment1.client;

import cs324.assignment1.common.BootstrapService;
import cs324.assignment1.common.WorkerInfo;
import cs324.assignment1.common.WorkerService;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;

public class ClientGUI extends JFrame {

    private final JTextField startField = new JTextField(8);
    private final JTextField endField = new JTextField(8);
    private final JComboBox<String> jobTypeBox = new JComboBox<>(new String[] {"MAX", "PRIMESUM", "PRIMECOUNT"});
    private final JTextArea outputArea = new JTextArea(12, 40);
    private final JButton submitButton = new JButton("Submit Job");
    private final JButton loadCsvButton = new JButton("Load CSV");

    private final String bootstrapHost = "localhost";
    private final int bootstrapPort = 1099;

    public ClientGUI() {
        super("CS324 Distributed Job Client");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Job Type:"));
        inputPanel.add(jobTypeBox);
        inputPanel.add(new JLabel("Start:"));
        inputPanel.add(startField);
        inputPanel.add(new JLabel("End:"));
        inputPanel.add(endField);
        inputPanel.add(submitButton);
        inputPanel.add(loadCsvButton);

        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        submitButton.addActionListener(e -> onSubmitClicked());
        loadCsvButton.addActionListener(e -> onLoadCsvClicked());

        pack();
        setLocationRelativeTo(null);
    }

    private void onSubmitClicked() {
        String jobType = (String) jobTypeBox.getSelectedItem();
        String startText = startField.getText().trim();
        String endText = endField.getText().trim();

        int start, end;
        try {
            start = Integer.parseInt(startText);
            end = Integer.parseInt(endText);
        } catch (NumberFormatException ex) {
            log("Error: Start and End must both be whole numbers.");
            return;
        }

        if (start > end) {
            log("Error: Start must be less than or equal to End.");
            return;
        }

        submitJobInBackground(jobType, start, end);
    }

    private void onLoadCsvClicked() {
    	 String desktopPath = System.getProperty("user.home") + "/Desktop";
         JFileChooser chooser = new JFileChooser(desktopPath);
         int result = chooser.showOpenDialog(this);
        if (result != JFileChooser.APPROVE_OPTION) {
            return;
        }

        java.io.File file = chooser.getSelectedFile();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                line = line.trim();
                if (line.isEmpty()) continue;

                // Expected CSV format per line: JOBTYPE,START,END
                // e.g.  PRIMECOUNT,1,1000
                String[] parts = line.split(",");
                if (parts.length != 3) {
                    log("Skipping line " + lineNumber + " (expected JOBTYPE,START,END): " + line);
                    continue;
                }

                String jobType = parts[0].trim().toUpperCase();
                int start, end;
                try {
                    start = Integer.parseInt(parts[1].trim());
                    end = Integer.parseInt(parts[2].trim());
                } catch (NumberFormatException ex) {
                    log("Skipping line " + lineNumber + " (invalid numbers): " + line);
                    continue;
                }

                log("Loaded from CSV line " + lineNumber + ": " + jobType + " [" + start + ", " + end + "]");
                submitJobInBackground(jobType, start, end);
            }
        } catch (Exception ex) {
            log("Failed to read CSV file: " + ex.getMessage());
        }
    }

    // Runs the RMI calls on a background thread so the GUI doesn't freeze
    // while waiting for the coordinator to compute and respond.
    private void submitJobInBackground(String jobType, int start, int end) {
        log("Submitting " + jobType + " [" + start + ", " + end + "] ...");

        new Thread(() -> {
            try {
                Registry bootstrapRegistry = LocateRegistry.getRegistry(bootstrapHost, bootstrapPort);
                BootstrapService bootstrap = (BootstrapService) bootstrapRegistry.lookup("BootstrapService");

                List<WorkerInfo> active = bootstrap.getActiveWorkers();
                if (active.isEmpty()) {
                    log("No active workers available.");
                    return;
                }

                // Ask any active worker who the current coordinator is.
                WorkerInfo anyWorker = active.get(0);
                Registry anyRegistry = LocateRegistry.getRegistry(anyWorker.getHost(), anyWorker.getPort());
                WorkerService anyService = (WorkerService) anyRegistry.lookup("Worker" + anyWorker.getId());
                int coordinatorId = anyService.getCoordinatorId();

                WorkerInfo coordinatorInfo = active.stream()
                        .filter(w -> w.getId() == coordinatorId)
                        .findFirst()
                        .orElse(null);

                if (coordinatorInfo == null) {
                    log("Could not find coordinator (Worker " + coordinatorId + ") in active worker list.");
                    return;
                }

                Registry coordRegistry = LocateRegistry.getRegistry(coordinatorInfo.getHost(), coordinatorInfo.getPort());
                WorkerService coordinatorService = (WorkerService) coordRegistry.lookup("Worker" + coordinatorInfo.getId());

                long result = coordinatorService.submitJob(jobType, start, end);
                log("Result for " + jobType + " [" + start + ", " + end + "] = " + result);

            } catch (Exception ex) {
                log("Job failed: " + ex.getMessage());
            }
        }).start();
    }

    private void log(String message) {
        SwingUtilities.invokeLater(() -> outputArea.append(message + "\n"));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ClientGUI gui = new ClientGUI();
            gui.setVisible(true);
        });
    }
}