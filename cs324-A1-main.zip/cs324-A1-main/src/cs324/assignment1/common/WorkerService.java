package cs324.assignment1.common;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface WorkerService extends Remote {
    int getId() throws RemoteException;

    void addNeighbour(WorkerInfo neighbour) throws RemoteException;

    void receiveElectionMessage(ElectionMessage msg) throws RemoteException;

    void reportCandidacy(WorkerInfo candidate, int jac, String electionId) throws RemoteException;

    void receiveCoordinatorMessage(CoordinatorMessage msg) throws RemoteException;

    int getJac() throws RemoteException;

    int getCoordinatorId() throws RemoteException;

    // Called on a SPECIFIC worker to actually compute a job over a range,
    // using multiple threads internally. Returns the computed result.
    long executeJob(String jobType, int start, int end) throws RemoteException;

    // Called by the CLIENT on whichever worker is currently the coordinator.
    // Splits the range across active workers, calls executeJob on each,
    // and combines their results into one final answer.
    long submitJob(String jobType, int start, int end) throws RemoteException;
}