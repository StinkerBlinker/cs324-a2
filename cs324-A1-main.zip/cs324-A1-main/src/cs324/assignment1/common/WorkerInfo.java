package cs324.assignment1.common;

import java.io.Serializable;

// Simple data class describing a worker, passed over RMI.
// Must implement Serializable since it travels across the network.
public class WorkerInfo implements Serializable {
    private final int id;
    private final String host;
    private final int port;

    public WorkerInfo(int id, String host, int port) {
        this.id = id;
        this.host = host;
        this.port = port;
    }

    public int getId() { return id; }
    public String getHost() { return host; }
    public int getPort() { return port; }
}