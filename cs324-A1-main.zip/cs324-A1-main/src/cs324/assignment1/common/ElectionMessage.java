package cs324.assignment1.common;

import java.io.Serializable;

// Sent when a worker starts (or forwards) a leader election.
// electionId uniquely identifies this specific election round, so
// workers can detect and ignore duplicates of the SAME election.
public class ElectionMessage implements Serializable {
    private final String electionId;
    private final WorkerInfo initiator;

    public ElectionMessage(String electionId, WorkerInfo initiator) {
        this.electionId = electionId;
        this.initiator = initiator;
    }

    public String getElectionId() { return electionId; }
    public WorkerInfo getInitiator() { return initiator; }
}