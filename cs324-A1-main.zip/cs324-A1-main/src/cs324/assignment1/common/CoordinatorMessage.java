package cs324.assignment1.common;

import java.io.Serializable;

// Flooded through the network once an election concludes, so every
// reachable worker learns who the new coordinator is.
public class CoordinatorMessage implements Serializable {
    private final String electionId;
    private final WorkerInfo coordinator;

    public CoordinatorMessage(String electionId, WorkerInfo coordinator) {
        this.electionId = electionId;
        this.coordinator = coordinator;
    }

    public String getElectionId() { return electionId; }
    public WorkerInfo getCoordinator() { return coordinator; }
}