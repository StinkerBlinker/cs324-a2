package cs324.assignment1.common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

// The Bootstrap Node exposes this interface so Workers can register
// and discover other active workers when they join the network.
public interface BootstrapService extends Remote {

    // Called by a new worker when it starts up. Returns its assigned unique ID.
    int registerWorker(String workerHost, int workerPort) throws RemoteException;

    // Called by a worker when it shuts down cleanly.
    void deregisterWorker(int workerId) throws RemoteException;

    // Returns currently active workers (so a new worker can pick a random one).
    List<WorkerInfo> getActiveWorkers() throws RemoteException;
}