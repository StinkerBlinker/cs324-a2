package cs324.assignment1.worker;

import cs324.assignment1.common.BootstrapService;
import cs324.assignment1.common.WorkerInfo;
import cs324.assignment1.common.WorkerService;
import cs324.assignment1.common.ElectionMessage;
import cs324.assignment1.common.CoordinatorMessage;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class WorkerNode extends UnicastRemoteObject implements WorkerService {

    private static final int TERM_JOB_LIMIT = 5;
    private static final long ELECTION_WAIT_MS = 2500L;

    private int id;
    private int port;
    private final List<WorkerInfo> neighbours = new CopyOnWriteArrayList<>();

    // Required by the assignment spec — do not rename or change the value.
    private final String leaderman = "cs324";

    private final AtomicInteger jac = new AtomicInteger(0);
    private final AtomicInteger jobsThisTerm = new AtomicInteger(0);
    private volatile int coordinatorId = -1;
    private volatile long lastAcceptedElectionTimestamp = -1L;
    private final AtomicBoolean electionInProgress = new AtomicBoolean(false);

    private BootstrapService bootstrapRef;

    private final Set<String> seenElections = ConcurrentHashMap.newKeySet();
    private final Set<String> seenCoordinations = ConcurrentHashMap.newKeySet();
    private final Map<String, Map<Integer, Integer>> jacByWorkerId = new ConcurrentHashMap<>();

    /**
     * Forwards ELECTION / COORDINATOR / candidacy reports on local threads so an
     * incoming RMI call can return immediately. Nested synchronous RMI callbacks
     * on the same TCP connection deadlock (that is the Worker 3/4 bug).
     */
    private final ExecutorService floodPool = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "flood-" + id);
        t.setDaemon(true);
        return t;
    });

    protected WorkerNode() throws RemoteException {
        super();
    }

    public static void main(String[] args) {
        System.setProperty("java.rmi.server.hostname", "localhost");
        try {
            String bootstrapHost = "localhost";
            int bootstrapPort = 1099;

            Registry bootstrapRegistry = LocateRegistry.getRegistry(bootstrapHost, bootstrapPort);
            BootstrapService bootstrap = (BootstrapService) bootstrapRegistry.lookup("BootstrapService");

            WorkerNode node = new WorkerNode();
            node.joinNetwork(bootstrap);

        } catch (Exception e) {
            System.err.println("[Worker] Failed to join network: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void joinNetwork(BootstrapService bootstrap) throws Exception {
        this.bootstrapRef = bootstrap;

        Registry myRegistry = null;
        Random random = new Random();
        for (int attempt = 0; attempt < 40 && myRegistry == null; attempt++) {
            this.port = 2000 + random.nextInt(1000);
            try {
                myRegistry = LocateRegistry.createRegistry(this.port);
            } catch (Exception ignored) {
                myRegistry = null;
            }
        }
        if (myRegistry == null) {
            throw new IllegalStateException("Could not bind an RMI registry for this worker");
        }

        this.id = bootstrap.registerWorker("localhost", this.port);
        myRegistry.rebind("Worker" + id, this);
        System.out.println("[Worker " + id + "] Registered successfully. leaderman=" + leaderman);
        System.out.println("[Worker " + id + "] Now listening on port " + this.port);

        List<WorkerInfo> activeWorkers = bootstrap.getActiveWorkers();
        List<WorkerInfo> others = activeWorkers.stream()
                .filter(w -> w.getId() != this.id)
                .toList();

        if (!others.isEmpty()) {
            WorkerInfo randomNeighbour = others.get(new Random().nextInt(others.size()));
            addNeighbourLocal(randomNeighbour);
            System.out.println("[Worker " + id + "] Connected to neighbour: Worker " + randomNeighbour.getId());

            WorkerService neighbourService = connect(randomNeighbour);
            neighbourService.addNeighbour(selfInfo());

            int existingCoordinator = neighbourService.getCoordinatorId();
            if (existingCoordinator == -1) {
                System.out.println("[Worker " + id + "] No coordinator known yet — starting an election.");
                startElection();
            } else {
                this.coordinatorId = existingCoordinator;
                System.out.println("[Worker " + id + "] Learned current coordinator: Worker " + coordinatorId);
            }
        } else {
            System.out.println("[Worker " + id + "] First worker in the network — self-electing as coordinator.");
            this.coordinatorId = this.id;
            this.jobsThisTerm.set(0);
        }
    }

    private WorkerInfo selfInfo() {
        return new WorkerInfo(this.id, "localhost", this.port);
    }

    private void addNeighbourLocal(WorkerInfo neighbour) {
        if (neighbour == null || neighbour.getId() == this.id) {
            return;
        }
        for (WorkerInfo existing : neighbours) {
            if (existing.getId() == neighbour.getId()) {
                return;
            }
        }
        neighbours.add(neighbour);
    }

    private WorkerService connect(WorkerInfo worker) throws Exception {
        Registry registry = LocateRegistry.getRegistry(worker.getHost(), worker.getPort());
        return (WorkerService) registry.lookup("Worker" + worker.getId());
    }

    private WorkerInfo findWorkerInfo(int workerId) {
        try {
            for (WorkerInfo w : bootstrapRef.getActiveWorkers()) {
                if (w.getId() == workerId) {
                    return w;
                }
            }
        } catch (Exception ignored) {
        }
        for (WorkerInfo w : neighbours) {
            if (w.getId() == workerId) {
                return w;
            }
        }
        if (workerId == this.id) {
            return selfInfo();
        }
        return new WorkerInfo(workerId, "localhost", -1);
    }

    @Override
    public int getId() throws RemoteException {
        return id;
    }

    @Override
    public void addNeighbour(WorkerInfo neighbour) throws RemoteException {
        addNeighbourLocal(neighbour);
        System.out.println("[Worker " + id + "] New neighbour added: Worker " + neighbour.getId());
    }

    @Override
    public int getJac() throws RemoteException {
        return jac.get();
    }

    @Override
    public int getCoordinatorId() throws RemoteException {
        return coordinatorId;
    }

    public void startElection() {
        if (!electionInProgress.compareAndSet(false, true)) {
            System.out.println("[Worker " + id + "] Election already in progress — not starting another.");
            return;
        }

        String electionId = this.id + "-" + System.currentTimeMillis();
        System.out.println("[Worker " + id + "] Starting election " + electionId);

        seenElections.add(electionId);
        Map<Integer, Integer> candidates = new ConcurrentHashMap<>();
        candidates.put(this.id, this.jac.get());
        jacByWorkerId.put(electionId, candidates);

        ElectionMessage msg = new ElectionMessage(electionId, selfInfo());
        floodElection(msg);

        floodPool.execute(() -> {
            waitForCandidates(electionId);
            concludeElection(electionId);
        });
    }

    private void waitForCandidates(String electionId) {
        long deadline = System.currentTimeMillis() + ELECTION_WAIT_MS;
        int expected = 0;
        try {
            expected = bootstrapRef.getActiveWorkers().size();
        } catch (Exception ignored) {
        }
        while (System.currentTimeMillis() < deadline) {
            int reported = jacByWorkerId.getOrDefault(electionId, Map.of()).size();
            if (expected > 0 && reported >= expected) {
                return;
            }
            try {
                Thread.sleep(50);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    private void floodElection(ElectionMessage msg) {
        for (WorkerInfo neighbour : neighbours) {
            final WorkerInfo target = neighbour;
            floodPool.execute(() -> forwardElection(target, msg));
        }
    }

    private void forwardElection(WorkerInfo neighbour, ElectionMessage msg) {
        try {
            connect(neighbour).receiveElectionMessage(msg);
        } catch (Exception e) {
            System.err.println("[Worker " + id + "] Could not reach neighbour " + neighbour.getId()
                    + " during election: " + e.getMessage());
        }
    }

    @Override
    public void receiveElectionMessage(ElectionMessage msg) throws RemoteException {
        String electionId = msg.getElectionId();
        if (!seenElections.add(electionId)) {
            return; // same ELECTION already processed — required by the spec
        }

        System.out.println("[Worker " + id + "] Received election " + electionId
                + ", forwarding and reporting candidacy.");

        electionInProgress.set(true);

        final WorkerInfo initiator = msg.getInitiator();
        final int myJac = this.jac.get();
        floodPool.execute(() -> {
            try {
                connect(initiator).reportCandidacy(selfInfo(), myJac, electionId);
            } catch (Exception e) {
                System.err.println("[Worker " + id + "] Could not report candidacy to initiator: "
                        + e.getMessage());
            }
        });

        floodElection(msg);
    }

    @Override
    public void reportCandidacy(WorkerInfo candidate, int candidateJac, String electionId)
            throws RemoteException {
        jacByWorkerId.computeIfAbsent(electionId, k -> new ConcurrentHashMap<>())
                .put(candidate.getId(), candidateJac);
        System.out.println("[Worker " + id + "] Candidacy received: Worker " + candidate.getId()
                + " (JAC=" + candidateJac + ")");
    }

    private void concludeElection(String electionId) {
        Map<Integer, Integer> candidates = jacByWorkerId.getOrDefault(electionId, Map.of());
        if (candidates.isEmpty()) {
            System.out.println("[Worker " + id + "] No candidates found for election " + electionId
                    + " — something went wrong.");
            electionInProgress.set(false);
            return;
        }

        int winnerId = -1;
        int winnerJac = Integer.MAX_VALUE;
        for (Map.Entry<Integer, Integer> entry : candidates.entrySet()) {
            int candidateId = entry.getKey();
            int candidateJac = entry.getValue();
            if (candidateJac < winnerJac || (candidateJac == winnerJac && candidateId > winnerId)) {
                winnerId = candidateId;
                winnerJac = candidateJac;
            }
        }

        System.out.println("[Worker " + id + "] Election " + electionId + " concluded. Winner: Worker "
                + winnerId + " (JAC=" + winnerJac + ")");

        WorkerInfo winnerInfo = findWorkerInfo(winnerId);
        applyCoordinator(electionId, winnerId);

        CoordinatorMessage coordMsg = new CoordinatorMessage(electionId, winnerInfo);
        seenCoordinations.add(electionId);
        floodCoordinator(coordMsg);
    }

    private void floodCoordinator(CoordinatorMessage msg) {
        for (WorkerInfo neighbour : neighbours) {
            final WorkerInfo target = neighbour;
            floodPool.execute(() -> forwardCoordinator(target, msg));
        }
    }

    private void forwardCoordinator(WorkerInfo neighbour, CoordinatorMessage msg) {
        try {
            connect(neighbour).receiveCoordinatorMessage(msg);
        } catch (Exception e) {
            System.err.println("[Worker " + id + "] Could not reach neighbour " + neighbour.getId()
                    + " with coordinator message: " + e.getMessage());
        }
    }

    @Override
    public void receiveCoordinatorMessage(CoordinatorMessage msg) throws RemoteException {
        String electionId = msg.getElectionId();
        if (!seenCoordinations.add(electionId)) {
            return;
        }
        applyCoordinator(electionId, msg.getCoordinator().getId());
        floodCoordinator(msg);
    }

    private synchronized void applyCoordinator(String electionId, int newCoordinatorId) {
        long timestamp = extractTimestamp(electionId);
        if (timestamp < lastAcceptedElectionTimestamp) {
            System.out.println("[Worker " + id + "] Ignoring stale coordinator announcement from older election "
                    + electionId);
            return;
        }
        lastAcceptedElectionTimestamp = timestamp;
        this.coordinatorId = newCoordinatorId;
        this.electionInProgress.set(false);
        if (this.id == newCoordinatorId) {
            this.jobsThisTerm.set(0);
        }
        System.out.println("[Worker " + id + "] New coordinator is Worker " + coordinatorId
                + " (election " + electionId + ")");
    }

    private long extractTimestamp(String electionId) {
        try {
            int dash = electionId.lastIndexOf('-');
            return Long.parseLong(electionId.substring(dash + 1));
        } catch (Exception e) {
            return -1L;
        }
    }

    /**
     * One client submission = one term job. JAC only grows when this coordinator
     * hands a chunk to a *different* worker. JAC is never reset — it is the
     * election metric (lowest JAC wins; ties go to highest ID).
     */
    @Override
    public long submitJob(String jobType, int start, int end) throws RemoteException {
        if (electionInProgress.get() && this.id != this.coordinatorId) {
            throw new RemoteException("Election in progress; retry once a coordinator is announced.");
        }
        if (this.id != this.coordinatorId) {
            throw new RemoteException("Worker " + id + " is not the current coordinator (coordinator is Worker "
                    + coordinatorId + ")");
        }

        int ticket = jobsThisTerm.incrementAndGet();
        if (ticket > TERM_JOB_LIMIT) {
            jobsThisTerm.decrementAndGet();
            startElection();
            throw new RemoteException("Coordinator term has ended after " + TERM_JOB_LIMIT
                    + " jobs. A new election has been started — resubmit to the new coordinator.");
        }

        try {
            List<WorkerInfo> active = bootstrapRef.getActiveWorkers();
            int n = active.size();
            if (n == 0) {
                throw new RemoteException("No active workers to assign the job to");
            }

            int rangeSize = end - start + 1;
            int baseChunk = rangeSize / n;
            int remainder = rangeSize % n;
            int cursor = start;

            List<Thread> threads = new ArrayList<>();
            List<Long> results = new CopyOnWriteArrayList<>();

            for (int i = 0; i < n; i++) {
                int size = baseChunk + (i < remainder ? 1 : 0);
                if (size == 0) {
                    continue;
                }
                int chunkStart = cursor;
                int chunkEnd = cursor + size - 1;
                cursor += size;

                WorkerInfo w = active.get(i);
                System.out.println("[Coordinator " + id + "] Assigning " + jobType + " range ["
                        + chunkStart + ", " + chunkEnd + "] to Worker " + w.getId());

                Thread t = new Thread(() -> {
                    try {
                        long result = connect(w).executeJob(jobType, chunkStart, chunkEnd);
                        results.add(result);
                    } catch (Exception e) {
                        System.err.println("[Coordinator " + id + "] Worker " + w.getId()
                                + " failed to execute its chunk: " + e.getMessage());
                    }
                }, "dispatch-" + id + "-" + w.getId());
                threads.add(t);
                t.start();

                if (w.getId() != this.id) {
                    int now = jac.incrementAndGet();
                    System.out.println("[Worker " + id + "] Assigned a job to Worker " + w.getId()
                            + ". JAC is now " + now);
                }
            }

            for (Thread t : threads) {
                try {
                    t.join();
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
            }

            return combineResults(jobType, results);
        } finally {
            if (ticket == TERM_JOB_LIMIT) {
                System.out.println("[Worker " + id + "] Completed job " + ticket + "/" + TERM_JOB_LIMIT
                        + " — term ending, starting new election.");
                startElection();
            }
        }
    }

    private long combineResults(String jobType, List<Long> results) {
        if (results.isEmpty()) {
            return 0;
        }
        if ("MAX".equals(jobType)) {
            long max = Long.MIN_VALUE;
            for (long r : results) {
                max = Math.max(max, r);
            }
            return max;
        }
        long sum = 0;
        for (long r : results) {
            sum += r;
        }
        return sum;
    }

    @Override
    public long executeJob(String jobType, int start, int end) throws RemoteException {
        System.out.println("[Worker " + id + "] Executing " + jobType + " on range [" + start + ", " + end + "]");

        int numThreads = Math.min(4, Math.max(1, Runtime.getRuntime().availableProcessors()));
        ExecutorService pool = Executors.newFixedThreadPool(numThreads);

        int rangeSize = end - start + 1;
        int chunkSize = Math.max(1, rangeSize / numThreads);

        List<Future<Long>> futures = new ArrayList<>();
        int cursor = start;
        while (cursor <= end) {
            int chunkStart = cursor;
            int chunkEnd = Math.min(end, cursor + chunkSize - 1);
            futures.add(pool.submit(() -> computeChunk(jobType, chunkStart, chunkEnd)));
            cursor = chunkEnd + 1;
        }

        long result = "MAX".equals(jobType) ? Long.MIN_VALUE : 0;
        for (Future<Long> f : futures) {
            try {
                long v = f.get();
                if ("MAX".equals(jobType)) {
                    result = Math.max(result, v);
                } else {
                    result += v;
                }
            } catch (Exception e) {
                System.err.println("[Worker " + id + "] Thread failed during job execution: " + e.getMessage());
            }
        }

        pool.shutdown();
        System.out.println("[Worker " + id + "] Finished " + jobType + " on [" + start + ", " + end + "] -> " + result);
        return result;
    }

    private long computeChunk(String jobType, int start, int end) {
        switch (jobType) {
            case "MAX": {
                long max = Long.MIN_VALUE;
                for (int i = start; i <= end; i++) {
                    max = Math.max(max, i);
                }
                return max;
            }
            case "PRIMESUM": {
                long sum = 0;
                for (int i = start; i <= end; i++) {
                    if (isPrime(i)) {
                        sum += i;
                    }
                }
                return sum;
            }
            case "PRIMECOUNT": {
                long count = 0;
                for (int i = start; i <= end; i++) {
                    if (isPrime(i)) {
                        count++;
                    }
                }
                return count;
            }
            default:
                return 0;
        }
    }

    private boolean isPrime(int n) {
        if (n < 2) {
            return false;
        }
        if (n == 2 || n == 3) {
            return true;
        }
        if (n % 2 == 0 || n % 3 == 0) {
            return false;
        }
        for (int i = 5; (long) i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) {
                return false;
            }
        }
        return true;
    }
}